package com.r.apisecurity03;

import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import com.android.volley.AuthFailureError;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.Request;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.JsonArrayRequest;
import com.android.volley.toolbox.JsonObjectRequest;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import java.util.HashMap;
import java.util.Map;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

public class MainActivity extends AppCompatActivity {
	
	ProgressBar progressBar;
	Button button1;
	TextView tvDisplay;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
		
		progressBar= findViewById(R.id.progressBar);
		button1= findViewById(R.id.button1);
		tvDisplay= findViewById(R.id.tvDisplay);
		
		
		button1.setOnClickListener(v->{
			
		progressBar.setVisibility(View.VISIBLE);
		
		arrayRequest();  ///Array Request Method
	
	
		//////  objectRequest();   //// object Request Method------//
		/////   stringRequest();  //// string Request Method-----//
		});
		
		
		
    }
	
	////-----------------//////////////////////////////
	private void arrayRequest() {
		String url = "https://string_url/";
		
		JSONArray jsonArray= new JSONArray();
		JSONObject jsonObject = new JSONObject(); // নতুন JSON অবজেক্ট তৈরি করা হলো
		try {
			jsonObject.put("pass", "30302");
			jsonObject.put("email", "rakibul20@gmail.com");
			} catch (JSONException e) {
			e.printStackTrace(); // ত্রুটি থাকলে কনসোলে প্রিন্ট করো
		}
		jsonArray.put(jsonObject);
		
		
		
		JsonArrayRequest jsonArrayRequest = new JsonArrayRequest(Request.Method.POST, url, jsonArray,
		
		new Response.Listener<JSONArray>() {
			@Override
			public void onResponse(JSONArray response) {
				progressBar.setVisibility(View.GONE);
				tvDisplay.setText(response.toString());
				
			}
		},
		new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				// ত্রুটি হ্যান্ডল করো
				progressBar.setVisibility(View.GONE);
				tvDisplay.setText("Error: "+error.getMessage());
			}
		});
		
		// RequestQueue তৈরি করে সেটাতে রিকোয়েস্ট যোগ করো
		RequestQueue requestQueue = Volley.newRequestQueue(this);
		requestQueue.add(jsonArrayRequest);
	}
	
	
	
	
	
	
	////////////////-----------------------------/////////////////
	private void objectRequest() {
		String url = "https://string_url/";
		
		JSONObject jsonObject = new JSONObject(); // নতুন JSON অবজেক্ট তৈরি করা হলো
		try {
			jsonObject.put("pass", "30302");
			jsonObject.put("email", "rakibul20@gmail.com");
			} catch (JSONException e) {
			e.printStackTrace(); // ত্রুটি থাকলে কনসোলে প্রিন্ট করো
		}
		
		JsonObjectRequest jsonObjectRequest = new JsonObjectRequest(
		Request.Method.POST, url, jsonObject,
		new Response.Listener<JSONObject>() {
			@Override
			public void onResponse(JSONObject response) {
				progressBar.setVisibility(View.GONE);
				tvDisplay.setText(response.toString());
			
			}
		},
		new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				// ত্রুটি হ্যান্ডল করো
				progressBar.setVisibility(View.GONE);
				tvDisplay.setText("Error: "+error.getMessage());
			}
		});
		
		// RequestQueue তৈরি করে সেটাতে রিকোয়েস্ট যোগ করো
		RequestQueue requestQueue = Volley.newRequestQueue(this);
		requestQueue.add(jsonObjectRequest);
	}
	
	
	//////---------+---------------------------//////////////////
	
	
	private void stringRequest() {
		String url = "https://string_url/";
		
		StringRequest stringRequest = new StringRequest(
		Request.Method.POST, url,  // GET থেকে POST করা হয়েছে
		new Response.Listener<String>() {
			@Override
			public void onResponse(String response) {
				// সার্ভারের রেসপন্স হ্যান্ডল করো
			}
		},
		new Response.ErrorListener() {
			@Override
			public void onErrorResponse(VolleyError error) {
				// ত্রুটি হ্যান্ডল করো
			}
			}) {
			@Override
			protected Map<String, String> getParams() throws AuthFailureError {
				Map<String, String> myMap = new HashMap<>();
				myMap.put("pass", "30303");
				myMap.put("Email", "sozib20@gmail.com");
				return myMap;
			}
		};
		
		
		
		RequestQueue requestQueue = Volley.newRequestQueue(this);
		requestQueue.add(stringRequest);
	}
	}